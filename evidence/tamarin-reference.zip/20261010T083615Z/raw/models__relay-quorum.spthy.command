timeout --signal=TERM --kill-after=10 180s tamarin-prover --prove --auto-sources --quit-on-warning --derivcheck-timeout=90 -c=30 -s=10 models/relay-quorum.spthy +RTS -N4 -RTS 
