timeout --signal=TERM --kill-after=10 300s tamarin-prover --prove --auto-sources --quit-on-warning --derivcheck-timeout=90 -c=30 -s=10 models/protocol-v2-e2e.spthy +RTS -N4 -RTS 
