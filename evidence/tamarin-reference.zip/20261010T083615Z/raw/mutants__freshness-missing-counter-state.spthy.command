timeout --signal=TERM --kill-after=10 150s tamarin-prover --prove --auto-sources --quit-on-warning --derivcheck-timeout=90 -c=30 -s=10 mutants/freshness-missing-counter-state.spthy +RTS -N4 -RTS 
