timeout --signal=TERM --kill-after=10 300s tamarin-prover --prove --auto-sources --quit-on-warning --derivcheck-timeout=90 -c=30 -s=10 mutants/settlement-missing-order-recompute.spthy +RTS -N4 -RTS 
